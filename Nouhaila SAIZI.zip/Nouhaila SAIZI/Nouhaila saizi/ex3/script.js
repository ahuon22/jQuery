$(document).ready(function() {
    let display = $('.calculator-screen');
    let currentInput = '';
    let operator = '';
    let previousInput = '';

    function updateDisplay(value) {
        display.val(value);
    }

    function calculate() {
        let result;
        if (previousInput !== '' && currentInput !== '') {
            result = eval(previousInput + operator + currentInput);
            previousInput = result;
            currentInput = '';
            operator = '';
            updateDisplay(result);
        }
    }

    $('.calculator-keys button').on('click', function() {
        const value = $(this).val();

        if ($(this).hasClass('operator')) {
            if (previousInput !== '' && currentInput !== '') {
                calculate();
            }
            operator = value;
            previousInput = display.val();
            currentInput = '';
        } else if (value === 'all-clear') {
            currentInput = '';
            operator = '';
            previousInput = '';
            updateDisplay('0');
        } else if (value === '=') {
            calculate();
        } else {
            currentInput += value;
            updateDisplay(currentInput);
        }
    });
});
