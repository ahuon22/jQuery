<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ex4";

$link = new mysqli($servername, $username, $password, $dbname);

if ($link->connect_error) {
    die("Connection failed: " . $link->connect_error);
}

$pays_id = $_GET['pays_id'];

$sql = "SELECT id, nom FROM regions WHERE pays_id = $pays_id";
$result = $link->query($sql);

$regions = array();
while($row = $result->fetch_assoc()) {
    $regions[] = $row;
}

$link->close();

echo json_encode($regions);
