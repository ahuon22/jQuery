<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste déroulante dynamique</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Liste déroulante dynamique</h1>
        <div class="form-group">
            <label for="pays">Pays:</label>
            <select id="pays" class="form-control">
                <option value="">Sélectionnez un pays</option>
            </select>
        </div>
        <div class="form-group">
            <label for="regions">Régions:</label>
            <select id="regions" class="form-control">
                <option value="">Sélectionnez une région</option>
            </select>
        </div>
        <div class="form-group">
            <label for="villes">Villes:</label>
            <select id="villes" class="form-control">
                <option value="">Sélectionnez une ville</option>
            </select>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'get_pays.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    // $('#pays').append('<option value="">Sélectionnez un pays</option>');
                    data.forEach(function(pays) {
                        $('#pays').append('<option value="' + pays.id + '">' + pays.nom + '</option>');
                    });
                }
            });
            $('#pays').change(function() {
                var pays_id = $(this).val();
                $('#regions').empty().append('<option value="">Sélectionnez une région</option>');
                $('#villes').empty().append('<option value="">Sélectionnez une ville</option>');
                if (pays_id) {
                    $.ajax({
                        url: 'get_regions.php',
                        method: 'GET',
                        data: { pays_id: pays_id },
                        dataType: 'json',
                        success: function(data) {
                            data.forEach(function(region) {
                                $('#regions').append('<option value="' + region.id + '">' + region.nom + '</option>');
                            });
                        }
                    });
                }
            });

            // Charger les villes en fonction de la région sélectionnée
            $('#regions').change(function() {
                var region_id = $(this).val();
                $('#villes').empty().append('<option value="">Sélectionnez une ville</option>');
                if (region_id) {
                    $.ajax({
                        url: 'get_villes.php',
                        method: 'GET',
                        data: { region_id: region_id },
                        dataType: 'json',
                        success: function(data) {
                            data.forEach(function(ville) {
                                $('#villes').append('<option value="' + ville.id + '">' + ville.nom + '</option>');
                            });
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
