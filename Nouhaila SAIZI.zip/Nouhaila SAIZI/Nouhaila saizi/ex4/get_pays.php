<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ex4";

$link = new mysqli($servername, $username, $password, $dbname);

if ($link->connect_error) {
    die("Connection failed: " . $link->connect_error);
}

$sql = "SELECT id, nom FROM pays";
$result = $link->query($sql);

$pays = array();
while($row = $result->fetch_assoc()) {
    $pays[] = $row;
}

$link->close();

echo json_encode($pays);

