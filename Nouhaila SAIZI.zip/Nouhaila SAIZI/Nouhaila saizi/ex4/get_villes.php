<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ex4";

$link = new mysqli($servername, $username, $password, $dbname);

if ($link->connect_error) {
    die("Connection failed: " . $link->connect_error);
}

$region_id = $_GET['region_id'];

$sql = "SELECT id, nom FROM villes WHERE region_id = $region_id";
$result = $link->query($sql);

$villes = array();
while($row = $result->fetch_assoc()) {
    $villes[] = $row;
}

$link->close();

echo json_encode($villes);
