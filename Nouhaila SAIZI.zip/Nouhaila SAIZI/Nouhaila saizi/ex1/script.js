$(document).ready(function(){
    $('#inscriptionForm').submit(function(event){
        var error = false;

        // Validation des champs obligatoires
        $('.required').each(function(){
            if ($(this).val().trim() === '') {
                error = true;
                $(this).addClass('is-invalid');
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        // Validation de l'email par regex
        var emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test($('#email').val())) {
            error = true;
            $('#email').addClass('is-invalid');
        } else {
            $('#email').removeClass('is-invalid');
        }

        // Validation du numéro de téléphone par regex
        var phoneRegex = /^\d{10}$/;
        if (!phoneRegex.test($('#telephone').val())) {
            error = true;
            $('#telephone').addClass('is-invalid');
        } else {
            $('#telephone').removeClass('is-invalid');
        }

        // Validation de la correspondance des mots de passe
        var password = $('#motdepasse').val();
        var confirmPassword = $('#confirmmotdepasse').val();
        if (password !== confirmPassword) {
            error = true;
            $('#motdepasse, #confirmmotdepasse').addClass('is-invalid');
            $('#passwordMismatch').removeClass('d-none');
        } else {
            $('#motdepasse, #confirmmotdepasse').removeClass('is-invalid');
            $('#passwordMismatch').addClass('d-none');
        }

        if (error) {
            $('#successMessage').addClass('d-none');
            $('#errorMessage').removeClass('d-none');
            event.preventDefault(); // Empêche la soumission du formulaire si des erreurs sont présentes
        } else {
            $('#errorMessage').addClass('d-none');
            $('#successMessage').removeClass('d-none');
        }
    });
});
